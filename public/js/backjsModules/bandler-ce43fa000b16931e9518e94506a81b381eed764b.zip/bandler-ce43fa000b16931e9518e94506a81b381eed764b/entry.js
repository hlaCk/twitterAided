import module1 from "./module1.js";
import module2 from "./module2.js";

module1();
module2();
