const module2 = () => {
  console.log("Hello from module2!");
};

export default module2;
