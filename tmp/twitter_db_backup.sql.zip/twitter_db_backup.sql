-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 21, 2019 at 02:38 PM
-- Server version: 5.7.28
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `twitter_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT '0',
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `admin` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `user_id`, `user_name`, `admin`, `created_at`, `updated_at`) VALUES
(6, 1, '', 1, '2019-10-20 18:37:55', '2019-10-20 18:38:30');

-- --------------------------------------------------------

--
-- Table structure for table `cron_lists`
--

CREATE TABLE `cron_lists` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `target_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complete` timestamp NULL DEFAULT NULL,
  `error` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screen_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_url_https` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `followers_count` double DEFAULT '0',
  `friends_count` double DEFAULT '0',
  `listed_count` double DEFAULT '0',
  `favourites_count` double DEFAULT '0',
  `statuses_count` double DEFAULT '0',
  `following` tinyint(4) DEFAULT NULL,
  `follow_request_sent` tinyint(4) DEFAULT NULL,
  `notifications` tinyint(4) DEFAULT NULL,
  `verified` tinyint(4) DEFAULT NULL,
  `protected` tinyint(4) DEFAULT NULL,
  `suspended` tinyint(4) DEFAULT NULL,
  `needs_phone_verification` tinyint(4) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screen_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_url_https` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `followers_count` double DEFAULT '0',
  `friends_count` double DEFAULT '0',
  `listed_count` double DEFAULT '0',
  `favourites_count` double DEFAULT '0',
  `statuses_count` double DEFAULT '0',
  `following` tinyint(4) DEFAULT NULL,
  `follow_request_sent` tinyint(4) DEFAULT NULL,
  `notifications` tinyint(4) DEFAULT NULL,
  `verified` tinyint(4) DEFAULT NULL,
  `protected` tinyint(4) DEFAULT NULL,
  `suspended` tinyint(4) DEFAULT NULL,
  `needs_phone_verification` tinyint(4) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(9, '2019_10_13_192643_create_t_users_table', 3),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_10_13_190851_laratrust_setup_tables', 2),
(12, '2014_10_12_000000_create_users_table', 6),
(10, '2019_10_14_010510_create_profiles_table', 4),
(11, '2019_10_14_062211_create_cron_lists_table', 5),
(15, '2019_10_15_211446_create_followers_table', 7),
(16, '2019_10_15_211506_create_friends_table', 7),
(17, '2019_10_20_000000_create_admins_table', 8),
(18, '2019_10_21_035819_create_to_do_lists_table', 9),
(20, '2019_10_21_035820_add_note_column_to_to_do_lists_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'create-users', 'Create Users', 'Create Users', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(2, 'read-users', 'Read Users', 'Read Users', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(3, 'update-users', 'Update Users', 'Update Users', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(4, 'delete-users', 'Delete Users', 'Delete Users', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(5, 'create-acl', 'Create Acl', 'Create Acl', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(6, 'read-acl', 'Read Acl', 'Read Acl', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(7, 'update-acl', 'Update Acl', 'Update Acl', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(8, 'delete-acl', 'Delete Acl', 'Delete Acl', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(9, 'read-profile', 'Read Profile', 'Read Profile', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(10, 'update-profile', 'Update Profile', 'Update Profile', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(11, 'create-profile', 'Create Profile', 'Create Profile', '2019-10-13 16:41:13', '2019-10-13 16:41:13');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified` tinyint(4) DEFAULT NULL,
  `profile_image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image_url_https` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suspended` tinyint(4) DEFAULT NULL,
  `needs_phone_verification` tinyint(4) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `location`, `description`, `url`, `verified`, `profile_image_url`, `profile_image_url_https`, `suspended`, `needs_phone_verification`, `creation_date`, `created_at`, `updated_at`) VALUES
(15, 11, 'الدمام', '#تابعني_اتابعك . #تضيفني_اضيفك https://t.co/yoQBBXl74b', 'https://t.co/bsDOV84Hpm', 0, 'http://pbs.twimg.com/profile_images/1155254118723858433/1hUiDuY-_normal.jpg', 'https://pbs.twimg.com/profile_images/1155254118723858433/1hUiDuY-_normal.jpg', 0, 0, '2019-01-27 08:00:41', '2019-10-21 05:13:32', '2019-10-21 05:13:32'),
(2, 3, 'Programmer, Encrypt, ex-HaCker', 'متقن للبرمجة بإحترافية بعدة لغات/أنظمة، متقن لتشفير/فك تشفير  النصوص والتطبيقات، متقن لمعالجة/إستغلال الثغرات البرمجية.\nولو كتبت اكثر من كذا ماحتصدق . 🤔✌', 'https://t.co/A5D5QCK4Oq', 0, 'http://pbs.twimg.com/profile_images/471021912286437376/NQhXjM-z_normal.jpeg', 'https://pbs.twimg.com/profile_images/471021912286437376/NQhXjM-z_normal.jpeg', 0, 0, '2010-07-07 18:49:57', '2019-10-15 06:15:35', '2019-10-15 06:15:35'),
(3, 1, 'HighLevelProgrammer/Decoder...', '@alhlaCk  Another Me  🎗💬\n\nاللهم إني فقدت نصف سعادتي حين مماته وها أنا أفقد النصف الأخر بدون مواساته.\n#عبدالله_الشرمي_يرحمه_الله اللهم بارد قبره وجنة مصيره.', 'https://t.co/1E7YHrDAbQ', 0, 'http://pbs.twimg.com/profile_images/518108006957862914/4Fvm1nE1_normal.jpeg', 'https://pbs.twimg.com/profile_images/518108006957862914/4Fvm1nE1_normal.jpeg', 0, 0, '2012-06-11 16:42:50', '2019-10-15 06:15:37', '2019-10-15 06:15:37'),
(5, 5, '', '', NULL, 0, 'http://pbs.twimg.com/profile_images/636667361328631808/AKdC9fJb_normal.jpg', 'https://pbs.twimg.com/profile_images/636667361328631808/AKdC9fJb_normal.jpg', 0, 0, '2012-07-09 00:34:54', '2019-10-15 06:26:18', '2019-10-15 06:26:18'),
(14, 10, 'الرياض', '#تابعني_أتابعك . #ضيفني_أضيفك مهتم بالدورات التدريبيه وإنشاء التطبيقات والتسويق والفلسفة والمنطق .https://t.co/L93yYRUMG4', 'https://t.co/bsDOV84Hpm', 0, 'http://pbs.twimg.com/profile_images/1158633753385885696/NJnsDEBU_normal.jpg', 'https://pbs.twimg.com/profile_images/1158633753385885696/NJnsDEBU_normal.jpg', 0, 0, '2017-03-31 17:50:34', '2019-10-20 18:50:02', '2019-10-20 18:50:02'),
(13, 9, '', 'تشلساوي __ دمي ازررق +++ اعشق الماورائيات', NULL, 0, 'http://pbs.twimg.com/profile_images/490756254768193537/SIkXdWqw_normal.jpeg', 'https://pbs.twimg.com/profile_images/490756254768193537/SIkXdWqw_normal.jpeg', 0, 0, '2013-05-18 22:05:31', '2019-10-20 18:02:53', '2019-10-20 18:02:53'),
(12, 8, '💔', 'تابعني ؟ اتابعك\nماتتابعني ؟ اشوتك 😌', NULL, 0, 'http://pbs.twimg.com/profile_images/1185798026293579776/JoDP6mf-_normal.jpg', 'https://pbs.twimg.com/profile_images/1185798026293579776/JoDP6mf-_normal.jpg', 0, 0, '2017-04-28 16:53:24', '2019-10-20 17:58:40', '2019-10-20 17:58:40');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'superadministrator', 'Superadministrator', 'Superadministrator', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(2, 'administrator', 'Administrator', 'Administrator', '2019-10-13 16:41:12', '2019-10-13 16:41:12'),
(3, 'user', 'User', 'User', '2019-10-13 16:41:12', '2019-10-13 16:41:12');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(9, 2),
(9, 3),
(10, 1),
(10, 2),
(10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `to_do_lists`
--

CREATE TABLE `to_do_lists` (
  `id` int(10) UNSIGNED NOT NULL,
  `entity_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `run_time` timestamp NULL DEFAULT NULL,
  `finish_time` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `to_do_lists`
--

INSERT INTO `to_do_lists` (`id`, `entity_type`, `entity_id`, `action`, `note`, `user_id`, `run_time`, `finish_time`, `status`, `created_at`, `updated_at`) VALUES
(1, 'App\\User', 1, 'test', NULL, NULL, '2019-10-21 01:36:04', '2019-10-21 02:09:21', 'completed', '2019-10-21 01:36:04', '2019-10-21 02:09:21'),
(2, 'App\\User', 1, 'ha ha', NULL, 1, '2019-10-21 01:42:59', '2019-10-21 02:09:21', 'completed', '2019-10-21 01:42:59', '2019-10-21 02:09:21'),
(3, 'App\\User', 1, 'TEST', NULL, NULL, '2019-10-21 01:47:40', '2019-10-21 02:09:21', 'completed', '2019-10-21 01:47:40', '2019-10-21 02:09:21'),
(4, 'App\\User', 1, 'testing', NULL, NULL, '2019-10-21 02:07:55', '2019-10-21 02:09:21', 'completed', '2019-10-21 01:48:25', '2019-10-21 02:09:21'),
(5, 'App\\User', 1, 'follow', NULL, NULL, NULL, NULL, 'pending', '2019-10-21 02:09:49', '2019-10-21 03:19:13'),
(6, 'App\\User', 1, 'MillN', 'NNN', 1, NULL, NULL, 'pending', '2019-10-21 02:18:30', '2019-10-21 02:23:17'),
(7, 'App\\User', 1, 'MillN2', 'TestNote2', 1, NULL, NULL, 'pending', '2019-10-21 02:22:26', '2019-10-21 02:22:26'),
(8, 'App\\User', 8, 'afsd', NULL, NULL, NULL, NULL, 'pending', '2019-10-21 03:39:15', '2019-10-21 03:39:15'),
(9, 'App\\User', 8, 'Read Followers', NULL, NULL, NULL, NULL, 'pending', '2019-10-21 03:43:53', '2019-10-21 03:43:53'),
(10, 'App\\User', 8, 'Read Followers', NULL, NULL, NULL, NULL, 'pending', '2019-10-21 03:46:59', '2019-10-21 03:46:59'),
(11, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:01:49', '2019-10-21 11:01:49'),
(12, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:05:40', '2019-10-21 11:05:40'),
(13, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:05:48', '2019-10-21 11:05:48'),
(14, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:06:45', '2019-10-21 11:06:45'),
(15, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:07:13', '2019-10-21 11:07:13'),
(16, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:08:23', '2019-10-21 11:08:23'),
(17, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:08:23', '2019-10-21 11:08:23'),
(18, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:09:44', '2019-10-21 11:09:44'),
(19, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:10:00', '2019-10-21 11:10:00'),
(20, 'App\\User', 1, 'testing', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:12:54', '2019-10-21 11:12:54'),
(21, 'App\\User', 1, 'Read Followers', NULL, 1, NULL, NULL, 'pending', '2019-10-21 11:13:48', '2019-10-21 11:13:48'),
(22, 'App\\User', 1, 'Read Followers', 'by 252', 1, NULL, NULL, 'pending', '2019-10-21 11:14:22', '2019-10-21 11:14:22'),
(23, 'App\\User', 1, 'readFollowers', 'by 252', NULL, NULL, NULL, 'pending', '2019-10-21 11:19:03', '2019-10-21 11:19:03'),
(24, 'App\\User', 1, 'readFollowers', 'by 252', 1, NULL, NULL, 'pending', '2019-10-21 11:37:08', '2019-10-21 11:37:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_oauth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_oauth_token_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_followers_count` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_friends_count` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_screen_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `token_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `t_oauth_token`, `t_oauth_token_secret`, `t_id`, `t_followers_count`, `t_friends_count`, `t_screen_name`, `t_name`, `last_update`, `status`, `token_key`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'mrhlack', NULL, NULL, NULL, '605690123-zqrFuh95sWsp0eNsGe1vRyQiDSdTva2APM3GrtQj', 'Vwb5O6pZI4BInouiwbWzYHn5Mj0t08o22qJxWFQR5S8z3', '605690123', '6734', '7373', 'mrhlack', 'Eng. Mohammad Fahad - Master ☕💻🚬', '2019-10-21 19:10:31', 'active', NULL, 'B2KsAJ6VupYfbi87Rz2vhp90wso0LE4ZgpXxo6OEvFRWFYnOaCswYQMO31NM', '2019-10-15 00:20:23', '2019-10-21 01:10:31'),
(8, 'so_much_6', NULL, NULL, NULL, '858046509669068801-6RVbK1dL2v6vRKxdgT1WdWkAlusW8c7', 'nsn30ldFAXQDZjsYlZA1SC1ZWzIHsmOott9i7zCK0C5XE', '858046509669068801', '428', '1455', 'so_much_6', '3fof ..♤', '2019-10-20 17:58:40', 'active', NULL, 'MjXadtLuNTx6XXv1CToURWP9DhonXqKbLTEWLk9KPcUDaQLDyAMwLOY3ksTD', '2019-10-20 17:58:40', '2019-10-20 17:58:40'),
(3, 'alhlaCk', NULL, NULL, NULL, '164031301-BA2hDR7mjvdD73Q7jukjj5jrHD6NwahqHhaIMXVm', '197x266GKsGiJs5H5lpgTxGxi7R5q4J60qusRvWQyhGe9', '164031301', '946', '195', 'alhlaCk', 'م. محمد فهد - ماستر ☕💻🚬', '2019-10-16 08:41:56', 'active', NULL, 'niQZTQ0AlWBS0s7Uz5YW3MO6dnB4QF0vtx52Fu6zwx9mF6ttiKsGwz6z7MDC', '2019-10-15 00:33:20', '2019-10-16 08:41:56'),
(5, 'anacls55', NULL, NULL, NULL, '630748991-y71uha8ycqqyk4U31xKVugYNakM2jkPJDhm1tFp9', '7qUYBp5e9xCLk7XSIT4IACCyhnJ8wmKMSiYD2Rykau7fn', '630748991', '712', '806', 'anacls55', 'S.Abdullah', '2019-10-16 07:46:57', 'inactive', NULL, NULL, '2019-10-15 06:26:18', '2019-10-21 04:57:24'),
(9, 'mto2003', NULL, NULL, NULL, '1439871241-Ob73IgqTmh1VV98suKgoJQPaXz86THVEsc50Es2', '9rI1DF7uT4LcCahTuiiWvNDrtMDHW7BDdJzWWqr2Nm1Wk', '1439871241', '840', '1716', 'mto2003', 'MtO / فولو فولوباك', '2019-10-21 00:38:53', 'inactive', NULL, NULL, '2019-10-20 18:02:53', '2019-10-21 00:39:16'),
(10, '11224X', NULL, NULL, NULL, '847914034062032897-9kjtPU7hLxkjMOklsOz5tr0ZnVw5MqG', 'IZQHmipAmI0RtdNZFkh7V7WutXwbDXiUuANmpYa6SDRZY', '847914034062032897', '7444', '7126', '11224X', 'S N I P E R', '2019-10-20 18:50:02', 'inactive', NULL, NULL, '2019-10-20 18:50:02', '2019-10-21 05:15:56'),
(11, '111black11', NULL, NULL, NULL, '1089478294972567552-pTFx6oJgTVrGKh5FHOKBdZsO5uoJVv', 'eBhM1rZSMNnRVakHPq383V94qj5Df9JBB0IKaciSwWWd3', '1089478294972567552', '3821', '4291', '111black11', 'B L A C K', '2019-10-21 05:13:32', 'active', NULL, NULL, '2019-10-21 05:13:32', '2019-10-21 05:13:32');

-- --------------------------------------------------------

--
-- Table structure for table `users_dc`
--

CREATE TABLE `users_dc` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_oauth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_oauth_token_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_followers_count` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_friends_count` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_screen_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `token_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_dc`
--

INSERT INTO `users_dc` (`id`, `name`, `email`, `email_verified_at`, `password`, `t_oauth_token`, `t_oauth_token_secret`, `t_id`, `t_followers_count`, `t_friends_count`, `t_screen_name`, `t_name`, `last_update`, `status`, `token_key`, `remember_token`, `created_at`, `updated_at`) VALUES
(7, 'alhlaCk', NULL, NULL, NULL, '164031301-fKvlcpSlkguw3Zf4GxIhf2XmtyugRQODdSUczcnZ', 'IgXiCx524eB9egaI3SzelCmlJb0knfAr58VkrNmmpxcjM', '164031301', '935', '150', 'alhlaCk', 'م. محمد فهد - ماستر ☕💻🚬', '2019-10-14 10:58:33', 'active', 'decodercan.com', 'DYd487QTG7Hb1XpaurXwhNYZ64NQgAT893Ho9TQpABWqDC8Tutl9rJR81rJ6', '2019-10-13 23:16:28', '2019-10-14 10:58:33'),
(8, 'alwdeea0', NULL, NULL, NULL, '565003493-WuXe2qmKoaWDKWgg9B2AyFyJ48C67uFsSMyIv1TZ', 'krTxz2B2jooNTEJslTKGj6SgNd4430fSaDxWizabfOP0Q', '565003493', '150', '231', 'alwdeea0', 'عمر الموسى', '2019-10-14 10:58:33', 'active', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 10:58:33'),
(6, '3fofC', NULL, NULL, NULL, '858046509669068801-bn6X8GZthHB5dIAGCyV12eHFw5WWwTo', 'tBt8PiCLgNnsMJ1mGJAns8vtiOi8nZZb9qDuGcRduNLE7', '858046509669068801', '266', '0', '3fofC', '3fof', '2019-10-14 14:12:15', 'active', 'decodercan.com', 'GgRt3TYYXoewrD84I6yCkbFrsNqpH4t4iTXhaxoLKCBYmq9pUMtZ2siGIYjk', '2019-10-13 22:40:41', '2019-10-14 14:12:15'),
(9, 'mhfsamsung', NULL, NULL, NULL, '2190263207-PPbHMBmHx3PcCzcLWHivIcedqmlr4gDGMd6ehAW', 'j8mh5P0WCVhPr3O6p0QuMM2w9mqLDG3dEdYeQGdErkgHD', '2190263207', '10313', '11128', 'mhfsamsung', 'محمد فرحات Mohammed', '2019-10-14 10:58:33', 'active', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 10:58:33'),
(10, 'Abody949494', NULL, NULL, NULL, '1182286939522785280-uPWmms7VmgDoz2AMe2Bbd5pR8D0OKV', '95e4cTswwmqeBghBhHm8KRcs3VVTWd73rPziJpVC89tDT', '1182286939522785280', '9', '0', 'Abody949494', 'Abody ♥', '2019-10-14 05:43:12', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:14:47'),
(11, 'sultan_kassar', NULL, NULL, NULL, '2316911105-XQVegs12CKB0Lh84rXXNpTllYuWuOJOpr90dR9P', '9CaKolIKucxJVdSTIG9tw6nO2hgETyj8lmLlxJe0IEg4O', '2316911105', '76', '342', 'sultan_kassar', 'SULTAN', '2019-10-14 05:43:14', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:15:04'),
(13, 'anacls55', NULL, NULL, NULL, '630748991-hlWTem6b6J5HNd03Zz2LDaiuJ8tWqO5v2ljEqGIF', 'gQYlpo3QkYPP4JRfN89OdvbAvFbzh2IAZiMDPyBy6UWiH', '630748991', '711', '805', 'anacls55', 'S.Abdullah', '2019-10-14 10:58:33', 'active', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 10:58:33'),
(14, 'ezFollow3', NULL, NULL, NULL, '1181232733642772480-0qRs9vlqp9bTh2iyZl4GlrwwBRwgE4', '07olwFLLJ40nwUD7PXiEj27xopxrAH6PFMfewPqKfPuMB', '1181232733642772480', '72', '235', 'ezFollow3', 'ezFollow', '2019-10-14 10:58:33', 'active', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 10:58:33'),
(29, 'mrhlack', NULL, NULL, NULL, '605690123-zqrFuh95sWsp0eNsGe1vRyQiDSdTva2APM3GrtQj', 'Vwb5O6pZI4BInouiwbWzYHn5Mj0t08o22qJxWFQR5S8z3', '605690123', '6642', '7186', 'mrhlack', 'Eng. Mohammad Fahad - Master ☕💻🚬', '2019-10-14 22:39:20', 'active', 'hlack.xyz', 'FSmEQY5z4JZIfx3mTskXuFb0uytanKJc4UONQEBZmWmBEmYGoPLbqcfz9faT', '2019-10-14 21:42:37', '2019-10-14 22:39:20'),
(16, 'mto2003', NULL, NULL, NULL, '1439871241-8vkWT05HZ2Di35z6TITY4cjczOD7IeWMvNNRhy8', 'xKh8YQMwjgw3zgiX0c3ZPDuhnfOBjhdOPEi6qSUOJyAyJ', '1439871241', '842', '1703', 'mto2003', 'MtO / فولو فولوباك', '2019-10-14 05:43:14', 'inactive', 'decodercan.com', NULL, '2019-10-13 23:16:28', '2019-10-14 06:15:02'),
(17, 'abduals01262294', NULL, NULL, NULL, '1182154203898232832-d6tLTiUc9Mvwqse7QY75r4YE0Odnwz', '2XYh6u2kbsVof3eARMfyzVphZzcoyayV2Ipbje0If26Rj', '1182154203898232832', '8', '0', 'abduals01262294', 'abdualslam', '2019-10-14 05:43:12', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:14:43'),
(18, 'haarrrarrrrara', NULL, NULL, NULL, '1182183972798959616-czVEstDVUxSqJmhQuDAylndJdYfmSa', 'fRDbQYTRU0K5IPPjYGp2T9BvKfzPb6DNJiyQYtLThANDy', '1182183972798959616', '9', '0', 'haarrrarrrrara', 'haarrrarrrrara', '2019-10-14 05:43:12', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:14:57'),
(19, 'somez12729540', NULL, NULL, NULL, '1182227525860282368-zUvq31PXNVjZ2W5NxZhL8s6DqaxXea', 'aXU7077szXj2w7lMWEQgncb2LAYV2DAGwoAKl8YEeMZvk', '1182227525860282368', '8', '0', 'somez12729540', 'somez', '2019-10-14 05:43:13', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:06:47'),
(21, 'somez96532293', NULL, NULL, NULL, '1182228563287838721-vqy9pJ9ZCvX1P2YMDzOSpQ9xAdC5SS', 'Msdk9qxCR6oduvXVJerE6CbArjoAQyk0JgUVlg7g63h0a', '1182228563287838721', '8', '0', 'somez96532293', 'somez', '2019-10-14 05:43:14', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:02:06'),
(22, 'somez58559605', NULL, NULL, NULL, '1182229458163507201-Ff134hVyHEdoVZh8tTusb79EzzwOJ0', 'qzTR1riVMjkyjzO2bceHVrI54lADEO4QenQjUFZZJv2CI', '1182229458163507201', '7', '0', 'somez58559605', 'somez', '2019-10-14 05:43:16', 'inactive', 'decodercan.com', NULL, '2019-10-13 23:16:28', '2019-10-14 06:04:20'),
(23, 'bbbmmmmmk', NULL, NULL, NULL, '1026741079415185408-uTtRzrijfnFYQzjyEqLkaE4slYGWHI', 'yWRf5OUItI1JDnGoTYlIKEnXzRpij0og5MV3h8v5JWYV3', '1026741079415185408', '8', '0', 'bbbmmmmmk', '...', '2019-10-14 05:43:12', 'inactive', 'decodercan.com', NULL, '2019-10-13 22:40:41', '2019-10-14 06:00:26'),
(24, 'kararm10772083', NULL, NULL, NULL, '1182258885803024384-l9ssgJRHO0aqlPl1IuLkOsiEv3uZzx', 'oXjIeXhn8cxatzbnETeB90LOHqDFDqi7bt71XLjIup4qj', '1182258885803024384', '8', '0', 'kararm10772083', 'بطاطس للبيع', '2019-10-14 05:43:14', 'inactive', 'decodercan.com', NULL, '2019-10-13 23:16:28', '2019-10-14 06:14:59'),
(25, 'D7oooooom1I', NULL, NULL, NULL, '1182308194028265473-29QDEbF1roqEIrYaqQnowN8qeSEdtb', '1gAbgnI7I2ibn2GAiJy0VM8FIFoSkQhD6j2iINb2lkOOq', '1182308194028265473', '8', '0', 'D7oooooom1I', 'iD7oooooom1', '2019-10-14 05:43:13', 'inactive', 'decodercan.com', NULL, '2019-10-13 23:16:28', '2019-10-14 06:14:52'),
(27, 'MyThBrittle', NULL, NULL, NULL, '377316648-p6lrse9Nrq9iJnT47fc7PdDH8ZX2tCP1wGfaiJ5K', 'mYitV5rTsK1e3wpXT1Xyf3m0vdN7Hso1lK49ECNs1U2Yi', '377316648', '14', '3', 'MyThBrittle', 'MyTh', '2019-10-14 10:58:34', 'active', 'decodercan.com', NULL, '2019-10-14 06:50:48', '2019-10-14 10:58:34'),
(28, 'Netrogeen', NULL, NULL, NULL, '782152655330213888-U539N0h3dtFmrJNspQDyn8GwFqGSALJ', '0ZvLwV2REtgTWzA22NijFkbjAh6wIMY8bkt7zbJyKQB8Q', '782152655330213888', '13', '45', 'Netrogeen', 'طير شلوا', '2019-10-14 10:58:34', 'active', 'decodercan.com', NULL, '2019-10-14 07:27:44', '2019-10-14 10:58:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE `user_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`role_id`, `user_id`, `user_type`) VALUES
(1, 1, 'App\\Models\\Auth\\User'),
(3, 3, 'App\\Models\\Auth\\User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cron_lists`
--
ALTER TABLE `cron_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `to_do_lists`
--
ALTER TABLE `to_do_lists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to_do_lists_entity_type_entity_id_index` (`entity_type`,`entity_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_dc`
--
ALTER TABLE `users_dc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD PRIMARY KEY (`user_id`,`permission_id`,`user_type`),
  ADD KEY `user_permissions_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`,`user_type`),
  ADD KEY `user_roles_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cron_lists`
--
ALTER TABLE `cron_lists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1896;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1519;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `to_do_lists`
--
ALTER TABLE `to_do_lists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users_dc`
--
ALTER TABLE `users_dc`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
